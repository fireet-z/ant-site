/**
 * 冒烟测试：启动服务器 -> API 断言 -> 清理 -> 退出
 * 供 `npm test` / `hermes verify` 使用。零外部依赖，仅用 node 内置模块。
 */
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');

const PORT = Number(process.env.SMOKE_PORT || 3199);
const BASE = `http://localhost:${PORT}`;
// 隔离数据目录：测试完全不触碰项目真实 data/uploads
const TMP_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'js-smoke-'));
const server = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], {
  env: { ...process.env, PORT: String(PORT), DATA_DIR: TMP_DIR, UPLOAD_DIR: path.join(TMP_DIR, 'uploads') },
  stdio: ['ignore', 'pipe', 'pipe']
});

let failures = 0;
const ok = (name, cond) => {
  console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}`);
  if (!cond) failures++;
};

function jfetch(p, opts = {}) {
  return fetch(BASE + p, {
    ...opts,
    headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) },
    body: opts.body ? JSON.stringify(opts.body) : undefined
  }).then(async r => ({ status: r.status, data: await r.json().catch(() => null) }));
}

async function waitReady(retries = 30) {
  for (let i = 0; i < retries; i++) {
    try {
      const r = await fetch(BASE + '/');
      if (r.ok) return true;
    } catch (e) { /* 未就绪 */ }
    await new Promise(r => setTimeout(r, 300));
  }
  return false;
}

(async () => {
  let createdId = null;
  try {
    const ready = await waitReady();
    ok('服务启动并响应 /', ready);
    if (!ready) throw new Error('server not ready');

    // 公开接口
    let r;
    r = await jfetch('/api/categories');
    ok('GET /api/categories -> 200 字符串数组', r.status === 200 && Array.isArray(r.data) && r.data.every(c => typeof c === 'string'));

    r = await jfetch('/api/sites');
    ok('GET /api/sites（游客）-> 200 数组', r.status === 200 && Array.isArray(r.data));

    // 未登录写入被拒
    r = await jfetch('/api/sites', { method: 'POST', body: { name: 'x', lat: 1, lng: 2 } });
    ok('未登录添加场地 -> 401', r.status === 401);

    // 登录
    r = await jfetch('/api/login', { method: 'POST', body: { username: 'admin', password: 'password' } });
    ok('登录 admin -> 200 含 token', r.status === 200 && !!r.data.token && r.data.role === 'admin');
    const AUTH = { Authorization: 'Bearer ' + r.data.token };

    // 错误密码
    r = await jfetch('/api/login', { method: 'POST', body: { username: 'admin', password: 'wrong' } });
    ok('错误密码 -> 401', r.status === 401);

    // 管理员 CRUD
    r = await jfetch('/api/sites', { method: 'POST', body: { name: '冒烟测试场地', lat: 30.1, lng: 120.1, address: '测试地址', contactPhone: '138-0000-9999', contact: '测试联系人' }, headers: AUTH });
    ok('管理员添加场地 -> 200 含 id', r.status === 200 && !!r.data.id);
    createdId = r.data && r.data.id;

    // 缺经纬度 -> 400
    r = await jfetch('/api/sites', { method: 'POST', body: { name: '无坐标' }, headers: AUTH });
    ok('缺经纬度 -> 400', r.status === 400);

    // AI 分析（未配置 Key -> 友好 500 错误而非挂起）
    r = await jfetch(`/api/sites/${createdId}/analyze`, { method: 'POST', headers: AUTH });
    ok('AI 分析未配置 Key -> 友好报错', r.status === 500 && /AI/.test(r.data.error || ''));

    // 游客脱敏：看不到 contactPhone/contact
    r = await jfetch('/api/sites');
    const guest = r.data.find(s => s.id === createdId);
    ok('游客隐藏联系方式', guest && !('contactPhone' in guest) && !('contact' in guest));

    // 管理员可见联系方式
    r = await jfetch('/api/sites', { headers: AUTH });
    const adminView = r.data.find(s => s.id === createdId);
    ok('管理员可见联系方式', adminView && adminView.contactPhone === '138-0000-9999');

    // 更新
    r = await jfetch(`/api/sites/${createdId}`, { method: 'PUT', body: { name: '冒烟测试场地-改', lat: 30.1, lng: 120.1 }, headers: AUTH });
    ok('更新场地 -> 200', r.status === 200 && r.data.name === '冒烟测试场地-改');

    // 自定义字段
    let fieldId = null;
    r = await jfetch('/api/fields');
    ok('GET /api/fields（游客）-> 200 数组', r.status === 200 && Array.isArray(r.data));
    r = await jfetch('/api/fields', { method: 'POST', body: { label: '测试自定义字段', type: 'radio', options: ['A', 'B'], visibleTo: ['admin'] }, headers: AUTH });
    ok('管理员添加字段 -> 200 含 id', r.status === 200 && !!r.data.id);
    fieldId = r.data && r.data.id;
    // 校验：radio 缺选项应 400
    r = await jfetch('/api/fields', { method: 'POST', body: { label: '坏字段', type: 'radio', options: [], visibleTo: ['admin'] }, headers: AUTH });
    ok('radio 缺选项 -> 400', r.status === 400);
    if (fieldId) {
      // 游客视角：看不到仅管理员可见的字段
      r = await jfetch('/api/fields');
      ok('游客看不到仅管理员的字段', !r.data.some(f => f.id === fieldId));
      // 管理员视角：可见
      r = await jfetch('/api/fields', { headers: AUTH });
      ok('管理员可见全部字段', r.data.some(f => f.id === fieldId));
      // 字段值脱敏：给场地写入该字段值
      r = await jfetch(`/api/sites/${createdId}`, { method: 'PUT', body: { name: '冒烟测试场地-改', lat: 30.1, lng: 120.1, fields: { [fieldId]: 'A' } }, headers: AUTH });
      ok('场地写入自定义字段值 -> 200', r.status === 200);
      r = await jfetch('/api/sites', { headers: AUTH });
      const adminSite = r.data.find(s => s.id === createdId);
      ok('管理员可见自定义字段值', adminSite.fields && adminSite.fields[fieldId] === 'A');
      r = await jfetch('/api/sites');
      const guestSite = r.data.find(s => s.id === createdId);
      ok('游客不可见自定义字段值', !guestSite.fields || !(fieldId in guestSite.fields));
      // 字段排序
      r = await jfetch('/api/fields', { method: 'POST', body: { label: '第二个字段', type: 'text', visibleTo: ['admin'] }, headers: AUTH });
      const fieldId2 = r.data && r.data.id;
      r = await jfetch('/api/fields/reorder', { method: 'POST', body: { ids: [fieldId2, fieldId] }, headers: AUTH });
      ok('字段排序 -> 200', r.status === 200 && r.data[0].id === fieldId2);
      // 清理
      r = await jfetch('/api/fields/' + fieldId, { method: 'DELETE', headers: AUTH });
      ok('删除字段 -> 200', r.status === 200);
      if (fieldId2) { await jfetch('/api/fields/' + fieldId2, { method: 'DELETE', headers: AUTH }); }
    }

    // 删除 admin 保护
    r = await jfetch('/api/users/admin', { method: 'DELETE', headers: AUTH });
    ok('删除 admin 被拒绝 -> 400', r.status === 400);

    // 删除测试场地
    r = await jfetch(`/api/sites/${createdId}`, { method: 'DELETE', headers: AUTH });
    ok('删除场地 -> 200', r.status === 200 && r.data.ok === true);

    // 导出
    r = await fetch(BASE + '/api/sites/export?format=json', { headers: AUTH });
    const text = await r.text();
    ok('导出 JSON -> 200 且可解析', r.status === 200 && (() => { try { JSON.parse(text); return true; } catch (e) { return false; } })());

    // ===== 自定义字段增强测试：必填校验 + CSV 往返 =====
    // 必填字段的服务端校验（绕过前端也应拦截）
    r = await jfetch('/api/fields', { method: 'POST', body: { label: '必填容量', type: 'text', required: true, visibleTo: ['admin', 'user'] }, headers: AUTH });
    const reqFieldId = r.data && r.data.id;
    ok('创建必填字段 -> 200', r.status === 200 && !!reqFieldId);
    r = await jfetch('/api/sites', { method: 'POST', body: { name: '字段必填测试', lat: 30.3, lng: 120.3, fields: {} }, headers: AUTH });
    ok('缺必填自定义字段保存 -> 400', r.status === 400 && /必填字段/.test(r.data.error || ''));
    // 填写必填字段后保存成功，并写入单选/多选值
    r = await jfetch('/api/fields', { method: 'POST', body: { label: '消防通道', type: 'checkbox', options: ['东侧', '西侧', '北侧'], visibleTo: ['admin', 'user', 'guest'] }, headers: AUTH });
    const cbFieldId = r.data && r.data.id;
    r = await jfetch('/api/sites', { method: 'POST', body: {
      name: '字段CSV测试场地', lat: 30.3, lng: 120.3, address: '字段测试地址',
      fields: { [reqFieldId]: '800KVA', [cbFieldId]: ['东侧', '北侧'] }
    }, headers: AUTH });
    ok('填写必填字段保存成功 -> 200', r.status === 200 && r.data.fields[reqFieldId] === '800KVA');
    const fieldSiteId = r.data && r.data.id;

    // CSV 导出：fields 列应序列化为 JSON，而非 [object Object]
    r = await fetch(BASE + '/api/sites/export?format=csv', { headers: AUTH });
    const csvText = await r.text();
    ok('CSV 导出 200 且 fields 列非 [object Object]', r.status === 200 && !csvText.includes('[object Object]') && csvText.includes('fields'));

    // CSV 导入往返：导出的 CSV 再导入，fields 值应正确还原
    const blob = new Blob([csvText], { type: 'text/csv' });
    const fd = new FormData();
    fd.append('file', blob, 'roundtrip.csv');
    fd.append('mode', 'append');
    const impResp = await fetch(BASE + '/api/sites/import', { method: 'POST', headers: AUTH, body: fd });
    const impData = await impResp.json();
    ok('CSV 导入成功', impResp.status === 200 && impData.added >= 1);
    r = await jfetch('/api/sites', { headers: AUTH });
    const imported = r.data.find(s => s.name === '字段CSV测试场地' && s.id !== fieldSiteId);
    ok('CSV 导入后 fields 值正确还原（含多选数组）', imported && imported.fields[reqFieldId] === '800KVA' && Array.isArray(imported.fields[cbFieldId]) && imported.fields[cbFieldId].includes('东侧'));

    // 删除字段后，场地中的孤儿值被同步清理
    if (reqFieldId) { await jfetch('/api/fields/' + reqFieldId, { method: 'DELETE', headers: AUTH }); }
    r = await jfetch('/api/sites', { headers: AUTH });
    ok('删除字段后场地值同步清理', !(reqFieldId in (r.data.find(s => s.id === fieldSiteId).fields || {})));
    if (cbFieldId) { await jfetch('/api/fields/' + cbFieldId, { method: 'DELETE', headers: AUTH }); }

    // ===== 导入自动去重 =====
    const dupSite = { name: '去重测试场地', lat: 31.1234564, lng: 121.7654324, address: '去重测试地址' };
    r = await jfetch('/api/sites', { method: 'POST', body: dupSite, headers: AUTH });
    ok('去重前置：创建场地 -> 200', r.status === 200);
    // 开启去重再导入同一条 -> 应跳过
    r = await jfetch('/api/sites/import', { method: 'POST', body: { sites: [{ ...dupSite }], mode: 'append', dedupe: true }, headers: AUTH });
    ok('去重导入重复场地 -> skipped=1 added=0', r.status === 200 && r.data.skipped === 1 && r.data.added === 0);
    // 关闭去重再导入 -> 应新增
    r = await jfetch('/api/sites/import', { method: 'POST', body: { sites: [{ ...dupSite }], mode: 'append', dedupe: false }, headers: AUTH });
    ok('不去重导入重复场地 -> added=1', r.status === 200 && r.data.added === 1 && r.data.skipped === 0);
    // 批内重复：同批两条相同数据 + 去重 -> 只新增 1 条
    r = await jfetch('/api/sites/import', { method: 'POST', body: { sites: [{ ...dupSite, name: '去重批内测试' }, { ...dupSite, name: '去重批内测试' }], mode: 'append', dedupe: true }, headers: AUTH });
    ok('批内重复去重 -> added=1 skipped=1', r.status === 200 && r.data.added === 1 && r.data.skipped === 1);

    // ===== 内置字段（internal）=====
    r = await jfetch('/api/fields/admin', { headers: AUTH });
    const internalFields = (r.data || []).filter(f => f.internal);
    ok('内置字段已预置（22 个非关键字段）', r.status === 200 && internalFields.length === 22);
    ok('内置字段含 regionType/leaseTerms 等', ['regionType', 'leaseTerms', 'description', 'contactPhone'].every(k => internalFields.some(f => f.id === k)));
    // 游客视角：contactPhone（仅管理员可见）不应出现在 /api/fields
    r = await jfetch('/api/fields');
    ok('游客字段列表不含 contactPhone', r.status === 200 && !r.data.some(f => f.id === 'contactPhone') && r.data.some(f => f.id === 'regionType'));
    // 场地写入内置字段值，游客视角应隐藏 contactPhone/contact 但可见 regionType
    r = await jfetch('/api/sites', { method: 'POST', body: { name: '内置字段测试场地', lat: 30.5, lng: 120.5, address: '内置测试地址', regionType: '城区', contactPhone: '138-0000-7777', contact: '内部联系人', landType: '建设用地', leaseTerms: '3年' }, headers: AUTH });
    ok('场地写入内置字段 -> 200', r.status === 200 && r.data.regionType === '城区');
    const internalSiteId = r.data && r.data.id;
    r = await jfetch('/api/sites');
    const guestView = r.data.find(s => s.id === internalSiteId);
    ok('游客隐藏 contactPhone/contact，可见 regionType', guestView && guestView.regionType === '城区' && guestView.contactPhone === undefined && guestView.contact === undefined);
    // 管理员可见
    r = await jfetch('/api/sites', { headers: AUTH });
    const adminView2 = r.data.find(s => s.id === internalSiteId);
    ok('管理员可见 contactPhone', adminView2 && adminView2.contactPhone === '138-0000-7777');
    // 删除内置字段 -> 同步清理所有场地该属性
    const leaseField = internalFields.find(f => f.id === 'leaseTerms');
    r = await jfetch('/api/fields/' + leaseField.id, { method: 'DELETE', headers: AUTH });
    ok('删除内置字段 -> 200', r.status === 200);
    r = await jfetch('/api/sites', { headers: AUTH });
    ok('删除内置字段后场地属性同步清理', (r.data.find(s => s.id === internalSiteId).leaseTerms === undefined));
    // 重新创建同名内置字段（恢复现场），并验证 API 创建不了 internal
    r = await jfetch('/api/fields', { method: 'POST', body: { label: '租赁条件', type: 'text', internal: true, visibleTo: ['admin', 'user', 'guest'] }, headers: AUTH });
    ok('API 创建的字段 internal 强制为 false', r.status === 200 && r.data.internal === false);
    const restoredLeaseId = r.data && r.data.id;
    r = await jfetch('/api/sites/' + internalSiteId, { method: 'PUT', body: { name: '内置字段测试场地', lat: 30.5, lng: 120.5, address: '内置测试地址', leaseTerms: '5年' }, headers: AUTH });
    ok('重建字段后可再次写入值', r.status === 200);
  } catch (e) {
    console.error('ERROR:', e.message);
    failures++;
  } finally {
    // 清理：删除测试残留
    try {
      const login = await jfetch('/api/login', { method: 'POST', body: { username: 'admin', password: 'password' } });
      if (login.data && login.data.token) {
        const H = { Authorization: 'Bearer ' + login.data.token };
        // 测试场地（冒烟测试 + 字段测试）
        const list = await jfetch('/api/sites', { headers: H });
        for (const s of list.data || []) {
          if (String(s.name).includes('冒烟测试') || String(s.name).includes('字段') || String(s.name).includes('必填') || String(s.name).includes('去重')) {
            await jfetch(`/api/sites/${s.id}`, { method: 'DELETE', headers: H });
          }
        }
        // 测试用户
        const users = await jfetch('/api/users', { headers: H });
        for (const u of users.data || []) {
          if (String(u.username).includes('fielduser') || String(u.username).includes('smoke')) {
            await jfetch(`/api/users/${u.id}`, { method: 'DELETE', headers: H });
          }
        }
        // 测试字段（避免污染真实字段配置）
        const fields = await jfetch('/api/fields/admin', { headers: H });
        for (const f of fields.data || []) {
          if (['测试自定义字段', '第二个字段', '坏字段', '必填容量', '消防通道', '字段必填'].includes(f.label)) {
            await jfetch('/api/fields/' + f.id, { method: 'DELETE', headers: H });
          }
        }
      }
    } catch (e) { /* 清理失败不阻塞结果 */ }
    server.kill();
    setTimeout(() => {
      fs.rmSync(TMP_DIR, { recursive: true, force: true });
      process.exit(failures ? 1 : 0);
    }, 300);
  }
})();
