/* =====================================================================
 * 简舜科技建站信息聚合平台 - 前端逻辑
 * 原生 JS (ES6) + Leaflet + 高德瓦片
 * ===================================================================== */
'use strict';

/* ---------------- 工具函数 ---------------- */
const $ = id => document.getElementById(id);
const $$ = sel => document.querySelectorAll(sel);

function esc(s) {
  return String(s === undefined || s === null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function toast(msg, type = '') {
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  el.textContent = msg;
  $('toast-container').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .3s'; }, 2400);
  setTimeout(() => el.remove(), 2800);
}

function debounce(fn, ms) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

function fmtDate(s) {
  if (!s) return '';
  const d = new Date(s);
  if (isNaN(d)) return s;
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

/** 下载 Blob 文件 */
function downloadBlob(content, filename, mime) {
  const blob = content instanceof Blob ? content : new Blob([content], { type: mime || 'application/octet-stream' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 500);
}

/** 极简 Markdown → HTML（AI 报告展示用） */
function mdToHtml(md) {
  if (!md) return '<p class="empty-tip">（无内容）</p>';
  let lines = String(md).replace(/\r\n/g, '\n').split('\n');
  let html = '', inCode = false, inTable = false, listType = null;
  const closeList = () => { if (listType) { html += `</${listType}>`; listType = null; } };
  for (let i = 0; i < lines.length; i++) {
    let line = lines[i];
    if (/^```/.test(line)) {
      if (inCode) { html += '</code></pre>'; inCode = false; }
      else { closeList(); html += '<pre><code>'; inCode = true; }
      continue;
    }
    if (inCode) { html += esc(line) + '\n'; continue; }
    if (/^\s*$/.test(line)) { closeList(); inTable = false; html += '<p></p>'; continue; }
    const escLine = l => esc(l)
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/\*([^*]+)\*/g, '<em>$1</em>')
      .replace(/`([^`]+)`/g, '<code>$1</code>');
    if (/^\s*\|.*\|\s*$/.test(line)) {
      closeList();
      const cells = line.replace(/^\s*\|/, '').replace(/\|\s*$/, '').split('|').map(c => c.trim());
      if (!inTable) { html += '<table><thead><tr>' + cells.map(c => `<th>${escLine(c)}</th>`).join('') + '</tr></thead><tbody>'; inTable = true; }
      else if (!/^[\s:|-]+$/.test(line.replace(/[|]/g, ''))) { html += '<tr>' + cells.map(c => `<td>${escLine(c)}</td>`).join('') + '</tr>'; }
      continue;
    }
    if (inTable) { html += '</tbody></table>'; inTable = false; }
    let m;
    if (m = line.match(/^###+\s+(.*)/)) { closeList(); html += `<h${Math.min(m[0].match(/^#+/)[0].length, 6)}>${escLine(m[1])}</h${Math.min(m[0].match(/^#+/)[0].length, 6)}>`; }
    else if (m = line.match(/^##\s+(.*)/)) { closeList(); html += `<h2>${escLine(m[1])}</h2>`; }
    else if (m = line.match(/^#\s+(.*)/)) { closeList(); html += `<h1>${escLine(m[1])}</h1>`; }
    else if (m = line.match(/^\s*[-*+]\s+(.*)/)) { if (listType !== 'ul') { closeList(); html += '<ul>'; listType = 'ul'; } html += `<li>${escLine(m[1])}</li>`; }
    else if (m = line.match(/^\s*\d+[.)]\s+(.*)/)) { if (listType !== 'ol') { closeList(); html += '<ol>'; listType = 'ol'; } html += `<li>${escLine(m[1])}</li>`; }
    else if (/^\s*---+\s*$/.test(line)) { closeList(); html += '<hr>'; }
    else if (m = line.match(/^\s*&gt;\s?(.*)/)) { closeList(); html += `<blockquote>${escLine(m[1])}</blockquote>`; }
    else { closeList(); html += `<p>${escLine(line)}</p>`; }
  }
  closeList();
  if (inCode) html += '</code></pre>';
  if (inTable) html += '</tbody></table>';
  return html;
}

/* ---------------- 全局状态 ---------------- */
const state = {
  token: localStorage.getItem('js_token') || '',
  user: localStorage.getItem('js_user') || '',
  role: localStorage.getItem('js_role') || '',
  sites: [],
  categories: [],
  fields: [],               // 当前角色可见的自定义字段
  selectedId: null,
  view: 'list',              // list | detail
  search: '',
  category: '',
  pickMode: null,            // null | 'top' | 'form'
  trafficOn: false,
  editId: null,
  pois: []                   // 表单中已获取的周边 POI
};

let map, markersLayer, poiLayer, heatLayer, trafficTimer;

/* ---------------- API 客户端 ---------------- */
async function api(path, opts = {}) {
  const headers = { ...(opts.headers || {}) };
  if (state.token) headers['Authorization'] = 'Bearer ' + state.token;
  if (opts.body && !(opts.body instanceof FormData) && typeof opts.body !== 'string') {
    headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(opts.body);
  }
  const resp = await fetch(path, { ...opts, headers });
  let data = null;
  try { data = await resp.json(); } catch (e) { /* 非 JSON 响应 */ }
  if (resp.status === 401 && state.token) {
    // token 失效：清除本地状态，提示重新登录
    state.token = ''; state.user = ''; state.role = '';
    localStorage.removeItem('js_token'); localStorage.removeItem('js_user'); localStorage.removeItem('js_role');
    updateAuthUI();
    toast('登录已过期，请重新登录', 'error');
  }
  if (!resp.ok) throw new Error((data && data.error) || `请求失败 (${resp.status})`);
  return data;
}

/* ---------------- 认证 ---------------- */
function updateAuthUI() {
  const logged = !!state.token;
  $('user-name').textContent = logged ? state.user : '登录';
  $$('.guest-only').forEach(el => el.classList.toggle('hidden', logged));
  $$('.logged-only').forEach(el => el.classList.toggle('hidden', !logged));
  $$('.admin-only').forEach(el => el.classList.toggle('hidden', !(logged && state.role === 'admin')));
  if (logged && state.role === 'admin') {
    $('map-buttons').classList.remove('hidden');
  }
  closeDropdowns();
}

async function doLogin(username, password) {
  const data = await api('/api/login', { method: 'POST', body: { username, password } });
  state.token = data.token; state.user = data.username; state.role = data.role;
  localStorage.setItem('js_token', data.token);
  localStorage.setItem('js_user', data.username);
  localStorage.setItem('js_role', data.role);
  updateAuthUI();
  await Promise.all([loadSites(), loadFields()]); // 管理员可看到联系方式与全部自定义字段
  toast('欢迎，' + data.username, 'success');
}

function doLogout() {
  state.token = ''; state.user = ''; state.role = '';
  localStorage.removeItem('js_token'); localStorage.removeItem('js_user'); localStorage.removeItem('js_role');
  updateAuthUI();
  loadSites();
  loadFields();
  toast('已退出登录');
}

/* ---------------- 数据加载 ---------------- */
async function loadSites() {
  state.sites = await api('/api/sites');
  state.selectedId = null;
  applyFilter();
}

async function loadCategories() {
  state.categories = await api('/api/categories');
  const filterSel = $('category-filter');
  const current = filterSel.value;
  filterSel.innerHTML = '<option value="">全部分类</option>' +
    state.categories.map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join('');
  filterSel.value = current;
}

/** 加载当前角色可见的自定义字段（登录态变化后需重新加载） */
async function loadFields() {
  state.fields = await api('/api/fields');
}

/* ---------------- 地图 ---------------- */
function initMap() {
  map = L.map('map', { zoomControl: true, attributionControl: true }).setView([34.34, 108.94], 5);
  // 高德矢量瓦片（GCJ-02）
  L.tileLayer('https://webrd0{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}', {
    subdomains: '1234',
    maxZoom: 18,
    attribution: '&copy; 高德地图'
  }).addTo(map);
  markersLayer = L.layerGroup().addTo(map);
  poiLayer = L.layerGroup().addTo(map);
  map.on('click', onMapClick);
  map.on('moveend zoomend', debounce(() => { if (state.trafficOn) refreshTraffic(); }, 500));
}

/** 数字标记（序号），选中紫色光圈 */
function renderMarkers(sites) {
  markersLayer.clearLayers();
  const bounds = [];
  sites.forEach((site, i) => {
    const num = i + 1;
    const icon = L.divIcon({
      className: '',
      html: `<div class="site-marker${site.id === state.selectedId ? ' selected' : ''}"><span>${num}</span></div>`,
      iconSize: [28, 28], iconAnchor: [14, 14], popupAnchor: [0, -16]
    });
    const marker = L.marker([site.lat, site.lng], { icon, zIndexOffset: site.id === state.selectedId ? 1000 : 0 });
    marker.bindPopup(
      `<div class="popup-name">${esc(site.name)}</div>` +
      `<div class="popup-addr"><i class="fas fa-map-marker-alt"></i> ${esc(site.address || '')}</div>` +
      `<button class="popup-detail-btn" data-site-id="${esc(site.id)}"><i class="fas fa-eye"></i> 查看详情</button>`,
      { closeButton: false }
    );
    marker.on('click', () => { marker.openPopup(); });
    marker.addTo(markersLayer);
    bounds.push([site.lat, site.lng]);
  });
  return bounds;
}

/** 周边 POI 标记 */
function renderPoiMarkers(pois) {
  poiLayer.clearLayers();
  (pois || []).forEach(p => {
    const [lng, lat] = String(p.location || '').split(',');
    if (!lng || !lat) return;
    const icon = L.divIcon({ className: '', html: '<div class="poi-marker"></div>', iconSize: [14, 14], iconAnchor: [7, 7] });
    const m = L.marker([parseFloat(lat), parseFloat(lng)], { icon });
    m.bindPopup(`<b>${esc(p.name)}</b><br>${esc(p.address || '')}<br>距离约 ${esc(p.distance)} 米`, { closeButton: false });
    m.addTo(poiLayer);
  });
}

/** 过滤 + 渲染 */
function applyFilter() {
  const kw = state.search.trim().toLowerCase();
  let filtered = state.sites.filter(s => {
    if (state.category && s.category !== state.category) return false;
    if (!kw) return true;
    const hay = [s.name, s.siteCode, s.address, s.contactPerson, s.contact, s.contactPhone, s.description, s.locationDesc, s.propertyOwner]
      .filter(v => v !== undefined && v !== null).join(' ').toLowerCase();
    return hay.includes(kw);
  });
  // 保持与当前状态一致：若选中的场地被过滤掉，清除选中
  if (state.selectedId && !filtered.some(s => s.id === state.selectedId)) state.selectedId = null;
  renderMarkers(filtered);
  $('panel-count').textContent = filtered.length ? `共 ${filtered.length} 个场地` : '';
  if (state.view === 'list') renderList(filtered);
  else if (state.selectedId) renderDetail(state.sites.find(s => s.id === state.selectedId));
  else { switchView('list'); renderList(filtered); }
  const empty = $('list-empty');
  empty.classList.toggle('hidden', filtered.length > 0 || state.view === 'detail');
  if (filtered.length) fitBounds(filtered);
}

function fitBounds(sites, padding = 60) {
  const bounds = sites.map(s => [s.lat, s.lng]);
  if (bounds.length === 1) map.setView(bounds[0], Math.max(map.getZoom(), 13));
  else if (bounds.length > 1) map.fitBounds(bounds, { padding: [padding, padding] });
}

function resetView() {
  const bounds = state.sites.map(s => [s.lat, s.lng]);
  if (bounds.length) fitBounds(state.sites);
  else map.setView([34.34, 108.94], 5);
}

/* ---------------- 选点模式 ---------------- */
function enterPickMode(source) {
  if (state.pickMode) return;
  state.pickMode = source;
  $('pick-hint').classList.remove('hidden');
  $('pick-point-btn').classList.add('active');
  map.getContainer().style.cursor = 'crosshair';
  if (source === 'form') closeModal('site-form-modal');
}

function exitPickMode() {
  state.pickMode = null;
  $('pick-hint').classList.add('hidden');
  $('pick-point-btn').classList.remove('active');
  map.getContainer().style.cursor = '';
}

function onMapClick(e) {
  if (!state.pickMode) return;
  const { lat, lng } = e.latlng;
  const src = state.pickMode;
  exitPickMode();
  if (src === 'form') {
    $('f-lat').value = lat.toFixed(6);
    $('f-lng').value = lng.toFixed(6);
    openModal('site-form-modal');
  } else {
    openSiteForm(null, { lat, lng });
  }
}

/* ---------------- 路况热力图 ---------------- */
async function refreshTraffic() {
  const b = map.getBounds();
  try {
    const points = await api(`/api/traffic/heatmap?minLng=${b.getWest()}&minLat=${b.getSouth()}&maxLng=${b.getEast()}&maxLat=${b.getNorth()}`);
    if (!state.trafficOn) return;
    if (heatLayer) map.removeLayer(heatLayer);
    if (!points.length) { toast('当前视野暂无路况数据'); return; }
    heatLayer = L.heatLayer(points.map(p => [p.lat, p.lng, p.intensity]), {
      radius: 26, blur: 22, maxZoom: 16,
      gradient: { 0.15: '#22c55e', 0.45: '#eab308', 0.75: '#f97316', 1: '#ef4444' }
    }).addTo(map);
  } catch (e) {
    if (state.trafficOn) toast(e.message, 'error');
  }
}

async function toggleTraffic() {
  state.trafficOn = !state.trafficOn;
  $('traffic-btn').classList.toggle('active', state.trafficOn);
  if (!state.trafficOn) {
    if (heatLayer) { map.removeLayer(heatLayer); heatLayer = null; }
    return;
  }
  await refreshTraffic();
}

/* ---------------- 列表视图 ---------------- */
function renderList(sites) {
  const box = $('site-list');
  const isAdmin = state.role === 'admin';
  box.innerHTML = sites.map(s => `
    <div class="site-card${s.id === state.selectedId ? ' selected' : ''}" data-id="${esc(s.id)}">
      <div class="sc-top">
        <span class="sc-name">${esc(s.name)}</span>
        ${s.category ? `<span class="badge">${esc(s.category)}</span>` : ''}
      </div>
      <div class="sc-line"><i class="fas fa-map-marker-alt"></i>${esc(s.address || '未填写地址')}</div>
      <div class="sc-line"><i class="fas fa-user"></i>${esc(s.contactPerson || '未填写')}</div>
      <div class="sc-line"><i class="fas fa-phone"></i>${isAdmin && s.contactPhone ? esc(s.contactPhone) : (isAdmin ? '未填写' : '——')}</div>
    </div>`).join('');
  box.querySelectorAll('.site-card').forEach(card => {
    card.onclick = () => {
      const id = card.dataset.id;
      state.selectedId = id;
      showDetail(id, { fly: true });
    };
  });
}

/* ---------------- 详情视图 ---------------- */
function switchView(view) {
  state.view = view;
  $('list-view').classList.toggle('hidden', view !== 'list');
  $('detail-view').classList.toggle('hidden', view !== 'detail');
  $('back-btn').classList.toggle('hidden', view !== 'detail');
  $('panel-title').textContent = view === 'list' ? '场地列表' : '场地详情';
}

function showDetail(id, { fly = true } = {}) {
  const site = state.sites.find(s => s.id === id);
  if (!site) return;
  state.selectedId = id;
  state.view = 'detail';
  switchView('detail');
  renderDetail(site);
  renderMarkers(state.sites); // 更新选中高亮与序号
  if (fly) map.flyTo([site.lat, site.lng], Math.max(map.getZoom(), 14), { duration: 0.8 });
  renderPoiMarkers(site.surroundingPois || []);
  if (isMobile()) {
    $('main').classList.add('detail-mode');
    setDrawer('full');
  }
}

function renderDetail(s) {
  const isAdmin = state.role === 'admin';
  const kv = (k, v, full) => `<div class="item${full ? ' full' : ''}"><span class="k">${k}</span><span>${v}</span></div>`;
  const y = v => esc(v !== undefined && v !== null && v !== '' ? v : '未填写');
  const media = (s.images || []).map((u, i) => {
    const isVideo = /\.(mp4|mov|webm)(\?|$)/i.test(u);
    const inner = isVideo
      ? `<video src="${esc(u)}" controls preload="metadata"></video>`
      : `<img src="${esc(u)}" loading="lazy" alt="">`;
    const ops = isAdmin ? `
      <div class="media-ops">
        <button class="mo-btn" data-media-act="left" data-media-idx="${i}" title="前移"><i class="fas fa-chevron-left"></i></button>
        <button class="mo-btn mo-del" data-media-act="del" data-media-idx="${i}" data-media-url="${esc(u)}" title="删除"><i class="fas fa-trash"></i></button>
        <button class="mo-btn" data-media-act="right" data-media-idx="${i}" title="后移"><i class="fas fa-chevron-right"></i></button>
      </div>` : '';
    return `<div class="media-item">${inner}${ops}</div>`;
  }).join('');

  // 内置字段（动态渲染，值存场地顶层属性；已删除的字段自动消失）
  const internalKv = (state.fields || []).filter(f => f.internal).map(f => {
    const v = s[f.id];
    if (v === undefined || v === null || v === '') return '';
    let display;
    if (f.id === 'canProvideProof') display = v === true ? '✅ 可提供' : v === false ? '❌ 不可提供' : esc(v);
    else if (Array.isArray(v)) display = esc(v.join('、'));
    else display = esc(v);
    return kv(f.label, display, f.id === 'locationDesc' || f.id === 'description');
  }).join('');

  // 自定义字段（仅展示当前角色可见且已填写的）
  const customKv = (state.fields || []).filter(f => !f.internal).filter(f => {
    const v = s.fields && s.fields[f.id];
    return v !== undefined && v !== null && v !== '' && (!Array.isArray(v) || v.length > 0);
  }).map(f => {
    let v = s.fields[f.id];
    if (Array.isArray(v)) v = v.join('、');
    return kv(f.label, esc(v), true);
  }).join('');

  $('detail-view').innerHTML = `
    <div class="detail">
      <div class="d-head">
        <div class="d-name">${y(s.name)}</div>
        ${s.category ? `<span class="badge">${esc(s.category)}</span>` : ''}
      </div>
      <div class="d-code">录入时间：${fmtDate(s.createdAt)}</div>

      <div class="d-section"><h4><i class="fas fa-info-circle"></i> 场地信息</h4>
        <div class="kv">
          ${kv('地址', y(s.address), true)}
          ${internalKv || '<div class="item full"><span class="k">其他信息</span><span>—</span></div>'}
        </div>
      </div>

      ${customKv ? `<div class="d-section"><h4><i class="fas fa-clipboard-list"></i> 自定义信息</h4><div class="kv">${customKv}</div></div>` : ''}

      ${media ? `<div class="d-section"><h4><i class="fas fa-images"></i> 现场照片 / 视频</h4><div class="d-media">${media}</div></div>` : ''}

      ${(s.surroundingPois && s.surroundingPois.length) ? `
      <div class="d-section"><h4><i class="fas fa-charging-station"></i> 周边 POI（${s.surroundingPois.length}）</h4>
        ${s.surroundingPois.map(p => `
          <div class="poi-item">
            <i class="fas fa-charging-station pi-icon"></i>
            <div><div class="pi-name">${esc(p.name)}</div><div class="pi-type">${esc(p.type || '')} · ${esc(p.address || '')}</div></div>
            <div class="pi-dist">${esc(p.distance)} m</div>
          </div>`).join('')}
      </div>` : ''}

      ${(s.aiReport || s.surroundingReport) ? `
      <div class="d-section"><h4><i class="fas fa-robot"></i> 历史报告</h4>
        ${s.aiReport ? `<div class="poi-item"><i class="fas fa-file-alt pi-icon"></i><div><div class="pi-name">建站分析报告</div><div class="pi-type">${fmtDate(s.aiReportDate)}</div></div><a class="report-link" data-report="ai">查看</a></div>` : ''}
        ${s.surroundingReport ? `<div class="poi-item"><i class="fas fa-file-alt pi-icon"></i><div><div class="pi-name">周边可行性分析</div><div class="pi-type">${fmtDate(s.surroundingReportDate)}</div></div><a class="report-link" data-report="surrounding">查看</a></div>` : ''}
      </div>` : ''}

      <div class="d-actions">
        <button class="btn btn-primary" id="share-btn"><i class="fas fa-share-alt"></i> 分享此场地</button>
        <button class="btn btn-outline" id="nav-btn"><i class="fas fa-directions"></i> 导航</button>
        ${isAdmin ? `
          <button class="btn btn-outline" id="upload-btn"><i class="fas fa-upload"></i> 上传</button>
          <button class="btn btn-outline" id="edit-btn"><i class="fas fa-edit"></i> 编辑</button>
          <button class="btn btn-outline" id="analyze-btn"><i class="fas fa-robot"></i> AI 分析报告</button>
          <button class="btn btn-outline" id="surrounding-btn"><i class="fas fa-search-location"></i> 周边分析</button>
          <button class="btn btn-danger" id="delete-btn"><i class="fas fa-trash"></i> 删除</button>
        ` : ''}
      </div>
    </div>`;

  // 绑定详情页事件
  $('share-btn').onclick = shareSite;
  $('nav-btn').onclick = openNavModal;
  // 媒体管理：删除 / 调整顺序（仅管理员渲染了按钮）
  document.querySelectorAll('#detail-view [data-media-act]').forEach(btn => {
    btn.onclick = (e) => {
      e.stopPropagation();
      const idx = Number(btn.dataset.mediaIdx);
      const act = btn.dataset.mediaAct;
      if (act === 'del') deleteMedia(idx);
      else moveMedia(idx, act === 'left' ? -1 : 1);
    };
  });
  if (isAdmin) {
    $('upload-btn').onclick = () => openUpload();
    $('edit-btn').onclick = () => openSiteForm(state.selectedId);
    $('delete-btn').onclick = () => confirmAction('删除场地', '确定要删除「' + s.name + '」吗？删除后不可恢复。', async () => {
      await api('/api/sites/' + state.selectedId, { method: 'DELETE' });
      toast('已删除', 'success');
      state.selectedId = null;
      switchView('list');
      loadSites();
    });
    $('analyze-btn').onclick = () => runAnalyze('ai');
    $('surrounding-btn').onclick = () => runAnalyze('surrounding');
  }
  document.querySelectorAll('.report-link').forEach(a => {
    a.onclick = () => showReport(state.selectedId, a.dataset.report);
  });
  $('detail-view').querySelectorAll('.d-media img, .d-media video').forEach(m => {
    m.onclick = () => openLightbox(m);
  });
}

/* ---------------- 导航 ---------------- */
function openNavModal() {
  const site = state.sites.find(s => s.id === state.selectedId);
  if (!site) return;
  $('nav-target').textContent = `${site.name || '场地'} ｜ ${site.address || '未填写地址'}`;
  openModal('nav-modal');
}

/** 调起地图 APP / 网页导航（坐标均为 GCJ-02，各家均用 coord 参数对齐） */
function launchNavigation(provider) {
  const site = state.sites.find(s => s.id === state.selectedId);
  if (!site) return;
  const name = encodeURIComponent(site.name || '场地');
  const { lat, lng } = site;
  let url = '';
  switch (provider) {
    case 'amap': // 高德 URI：to=经度,纬度,名称；手机浏览器自动调起 App
      url = `https://uri.amap.com/navigation?to=${lng},${lat},${name}&mode=car&coordinate=gaode&callnative=1`;
      break;
    case 'baidu': // 百度：coord_type=gcj02 直接使用
      url = `https://api.map.baidu.com/direction?destination=lat:${lat},lng:${lng}&coord_type=gcj02&mode=driving&origin=我的位置&output=html&src=jianshun-site`;
      break;
    case 'tencent': // 腾讯 URI：tocoord=纬度,经度
      url = `https://apis.map.qq.com/uri/v1/routeplan?type=drive&to=${name}&tocoord=${lat},${lng}&referer=jianshun-site`;
      break;
    case 'apple': // 苹果 / 系统地图
      url = `http://maps.apple.com/?daddr=${lat},${lng}&q=${name}`;
      break;
    default: return;
  }
  closeModal('nav-modal');
  window.open(url, '_blank');
}

/* ---------------- 媒体管理（删除 / 排序） ---------------- */
async function deleteMedia(idx) {
  const site = state.sites.find(s => s.id === state.selectedId);
  if (!site || !site.images[idx]) return;
  const targetId = site.id;
  const url = site.images[idx];
  const filename = String(url).split('/').pop();
  confirmAction('删除媒体文件', '确定删除这张图片/视频吗？文件将从服务器移除，不可恢复。', async () => {
    try {
      await api('/api/upload/' + encodeURIComponent(filename), { method: 'DELETE' });
    } catch (e) { /* 文件可能已不存在，忽略，继续更新场地数据 */ }
    await api('/api/sites/' + targetId, {
      method: 'PUT',
      body: { ...site, images: site.images.filter((_, i) => i !== idx) }
    });
    toast('已删除', 'success');
    await loadSites();
    state.selectedId = targetId;
    showDetail(targetId, { fly: false });
  });
}

async function moveMedia(idx, dir) {
  const site = state.sites.find(s => s.id === state.selectedId);
  if (!site) return;
  const targetId = site.id;
  const imgs = [...site.images];
  const j = idx + dir;
  if (j < 0 || j >= imgs.length) return;
  [imgs[idx], imgs[j]] = [imgs[j], imgs[idx]];
  try {
    await api('/api/sites/' + targetId, { method: 'PUT', body: { ...site, images: imgs } });
    await loadSites();
    state.selectedId = targetId;
    showDetail(targetId, { fly: false });
  } catch (e) { toast(e.message, 'error'); }
}

/* ---------------- 分享 ---------------- */
function shareSite() {
  const id = state.selectedId;
  if (!id) return;
  const url = location.origin + location.pathname + '?id=' + encodeURIComponent(id);
  const done = () => toast('链接已复制，可分享到微信等平台', 'success');
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(url).then(done).catch(() => fallbackCopy(url, done));
  } else fallbackCopy(url, done);
}

function fallbackCopy(text, done) {
  const ta = document.createElement('textarea');
  ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
  document.body.appendChild(ta); ta.select();
  try { document.execCommand('copy'); done(); } catch (e) { prompt('请手动复制链接：', text); }
  ta.remove();
}

/* ---------------- 表单（添加/编辑） ---------------- */
function openSiteForm(id, preset) {
  state.editId = id || null;
  const site = id ? state.sites.find(s => s.id === id) : null;
  $('site-form-title').innerHTML = site
    ? '<i class="fas fa-edit"></i> 编辑场地'
    : '<i class="fas fa-plus"></i> 添加场地';
  $('site-form-submit').innerHTML = '<i class="fas fa-save"></i> 保存场地';
  const f = (name, val) => { const el = $('f-' + name); if (el) el.value = val !== undefined && val !== null ? val : ''; };
  f('name', site && site.name); f('address', site && site.address);
  f('lat', preset ? preset.lat : (site && site.lat)); f('lng', preset ? preset.lng : (site && site.lng));
  state.pois = (site && site.surroundingPois) || [];
  renderFormPois();
  renderInternalFormFields(site);
  renderCustomFormFields(site);
  openModal('site-form-modal');
}

function collectForm() {
  const v = id => $('f-' + id).value.trim();
  return {
    name: v('name'), address: v('address'),
    lat: parseFloat(v('lat')), lng: parseFloat(v('lng')),
    surroundingPois: state.pois,
    ...collectInternalFields(),
    fields: collectCustomFields()
  };
}

async function submitSiteForm() {
  const body = collectForm();
  if (!body.name) return toast('请填写场地名称', 'error');
  if (!body.address) return toast('请填写详细地址', 'error');
  if (!isFinite(body.lat) || !isFinite(body.lng)) return toast('请先在地图上选取经纬度', 'error');
  for (const f of state.fields) {
    if (!f.required) continue;
    const v = f.internal ? body[f.id] : body.fields[f.id];
    if (v === '' || v === undefined || v === null || (Array.isArray(v) && v.length === 0)) {
      return toast(`请填写「${f.label}」`, 'error');
    }
  }
  try {
    let targetId = state.editId;
    if (state.editId) {
      await api('/api/sites/' + state.editId, { method: 'PUT', body });
      toast('场地已更新', 'success');
    } else {
      const created = await api('/api/sites', { method: 'POST', body });
      toast('场地已添加', 'success');
      targetId = created.id;
    }
    closeModal('site-form-modal');
    await loadSites();
    if (targetId) { state.selectedId = targetId; showDetail(targetId, { fly: true }); }
  } catch (e) { toast(e.message, 'error'); }
}

function renderFormPois() {
  const box = $('f-poi-box');
  if (!state.pois.length) { box.classList.add('hidden'); return; }
  box.classList.remove('hidden');
  $('f-poi-list').innerHTML = state.pois.map((p, i) => `
    <div class="poi-item">
      <i class="fas fa-charging-station pi-icon"></i>
      <div class="pi-name">${esc(p.name)}</div>
      <div class="pi-type">${esc(p.distance)} m</div>
      <button class="btn btn-sm btn-outline" data-poi-del="${i}"><i class="fas fa-times"></i></button>
    </div>`).join('');
  $('f-poi-list').querySelectorAll('[data-poi-del]').forEach(b => {
    b.onclick = () => { state.pois.splice(Number(b.dataset.poiDel), 1); renderFormPois(); };
  });
}

/* ---------------- 动态字段：渲染与收集（内置字段 + 自定义字段共用） ---------------- */
/** 生成单个字段控件 HTML；prefix 区分内置(if-)与自定义(cf-)字段的 DOM id */
function buildFieldControl(f, val, prefix) {
  const req = f.required ? ' <span class="req-star">*</span>' : '';
  const ph = esc(f.placeholder || '');
  const id = prefix + f.id;
  let input = '';
  switch (f.type) {
    case 'textarea':
      input = `<textarea id="${id}" rows="2" placeholder="${ph}">${esc(Array.isArray(val) ? val.join('、') : val || '')}</textarea>`;
      break;
    case 'number':
      input = `<input id="${id}" type="number" step="any" placeholder="${ph}" value="${esc(val !== undefined && val !== null ? val : '')}">`;
      break;
    case 'radio': {
      // canProvideProof 存储为布尔，渲染时映射为 是/否
      let cur = val;
      if (f.id === 'canProvideProof' && typeof cur === 'boolean') cur = cur ? '是' : '否';
      input = `<div class="cf-group">${f.options.map(o =>
        `<label class="cf-opt"><input type="radio" name="${id}" value="${esc(o)}" ${String(cur) === o ? 'checked' : ''}> ${esc(o)}</label>`).join('')}</div>`;
      break;
    }
    case 'select': {
      // 类别字段选项跟随分类管理动态变化
      const opts = (f.id === 'category' && state.categories.length) ? state.categories : f.options;
      input = `<select id="${id}"><option value="">请选择</option>${opts.map(o =>
        `<option value="${esc(o)}" ${String(val !== undefined && val !== null ? val : '') === o ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select>`;
      break;
    }
    case 'checkbox':
      input = `<div class="cf-group">${f.options.map(o =>
        `<label class="cf-opt"><input type="checkbox" data-fid="${f.id}" value="${esc(o)}" ${(val || []).includes(o) ? 'checked' : ''}> ${esc(o)}</label>`).join('')}</div>`;
      break;
    default: // text
      input = `<input id="${id}" type="text" placeholder="${ph}" value="${esc(val || '')}">`;
  }
  return `<label class="span-2">${esc(f.label)}${req}${input}</label>`;
}

/** 渲染内置字段区（值存场地顶层属性） */
function renderInternalFormFields(site) {
  const internal = (state.fields || []).filter(f => f.internal);
  const section = $('internal-fields-section');
  if (!internal.length) { section.classList.add('hidden'); return; }
  section.classList.remove('hidden');
  $('internal-fields-grid').innerHTML = internal.map(f => {
    const val = site ? site[f.id] : undefined;
    return buildFieldControl(f, val, 'if-');
  }).join('');
}

/** 渲染自定义字段区（值存 site.fields 对象） */
function renderCustomFormFields(site) {
  const custom = (state.fields || []).filter(f => !f.internal);
  const section = $('custom-fields-section');
  if (!custom.length) { section.classList.add('hidden'); return; }
  section.classList.remove('hidden');
  $('custom-fields-grid').innerHTML = custom.map(f => {
    const val = site && site.fields ? site.fields[f.id] : undefined;
    return buildFieldControl(f, val, 'cf-');
  }).join('');
}

/** 收集内置字段 → 场地顶层属性（canProvideProof 转布尔） */
function collectInternalFields() {
  const out = {};
  for (const f of state.fields) {
    if (!f.internal) continue;
    let v;
    if (f.type === 'checkbox') {
      v = [...document.querySelectorAll(`input[data-fid="${f.id}"]:checked`)].map(cb => cb.value);
    } else if (f.type === 'radio') {
      const sel = document.querySelector(`input[name="if-${f.id}"]:checked`);
      v = sel ? sel.value : '';
    } else {
      const el = document.getElementById('if-' + f.id);
      v = el ? el.value.trim() : '';
    }
    if (f.id === 'canProvideProof') {
      if (v === '是') out.canProvideProof = true;
      else if (v === '否') out.canProvideProof = false;
      // 未选择则不携带该键（保留原值）
    } else if (f.type === 'number') {
      out[f.id] = v ? Number(v) : '';
    } else {
      out[f.id] = v;
    }
  }
  return out;
}

/** 收集自定义字段 → fields 对象 */
function collectCustomFields() {
  const out = {};
  for (const f of state.fields) {
    if (f.internal) continue;
    if (f.type === 'checkbox') {
      out[f.id] = [...document.querySelectorAll(`input[data-fid="${f.id}"]:checked`)].map(cb => cb.value);
    } else if (f.type === 'radio') {
      const sel = document.querySelector(`input[name="cf-${f.id}"]:checked`);
      out[f.id] = sel ? sel.value : '';
    } else {
      const el = document.getElementById('cf-' + f.id);
      out[f.id] = el ? el.value.trim() : '';
    }
  }
  return out;
}

async function fetchFormPois() {
  const lat = parseFloat($('f-lat').value), lng = parseFloat($('f-lng').value);
  if (!isFinite(lat) || !isFinite(lng)) return toast('请先填写或选取经纬度', 'error');
  try {
    state.pois = await api('/api/surrounding-pois', { method: 'POST', body: { lng, lat, radius: 5000 } });
    renderFormPois();
    toast(`已获取 ${state.pois.length} 个周边站点`);
  } catch (e) { toast(e.message, 'error'); }
}

/* ---------------- 多媒体上传 ---------------- */
function openUpload() {
  const input = document.createElement('input');
  input.type = 'file'; input.multiple = true;
  input.accept = 'image/jpeg,image/png,image/gif,image/webp,video/mp4,video/quicktime,video/webm';
  input.onchange = () => uploadFiles(input.files);
  input.click();
}

function uploadFiles(files) {
  if (!files.length) return;
  const fd = new FormData();
  for (const f of files) fd.append('files', f);
  const xhr = new XMLHttpRequest();
  xhr.open('POST', '/api/upload');
  xhr.setRequestHeader('Authorization', 'Bearer ' + state.token);
  const toastEl = document.createElement('div');
  toastEl.className = 'toast'; toastEl.textContent = '上传中 0%';
  $('toast-container').appendChild(toastEl);
  xhr.upload.onprogress = e => {
    if (e.lengthComputable) toastEl.textContent = `上传中 ${Math.round(e.loaded / e.total * 100)}%`;
  };
  xhr.onload = async () => {
    try {
      const data = JSON.parse(xhr.responseText);
      if (xhr.status !== 200) throw new Error(data.error || '上传失败');
      toastEl.remove();
      toast(`已上传 ${data.files.length} 个文件`, 'success');
      const site = state.sites.find(s => s.id === state.selectedId);
      if (site) {
        await api('/api/sites/' + site.id, { method: 'PUT', body: { ...site, images: [...(site.images || []), ...data.files] } });
        await loadSites();
        showDetail(site.id, { fly: false });
      }
    } catch (e) { toastEl.remove(); toast(e.message, 'error'); }
  };
  xhr.onerror = () => { toastEl.remove(); toast('上传失败，请检查网络', 'error'); };
  xhr.send(fd);
}

/* ---------------- AI 分析 ---------------- */
async function runAnalyze(type) {
  const site = state.sites.find(s => s.id === state.selectedId);
  if (!site) return;
  openReportModal(type === 'ai' ? '建站分析报告' : '周边可行性分析');
  try {
    const path = type === 'ai' ? `/api/sites/${site.id}/analyze` : `/api/sites/${site.id}/analyze-surrounding`;
    const data = await api(path, { method: 'POST' });
    $('report-body').innerHTML = mdToHtml(data.report);
    $('report-download').onclick = () => downloadBlob(data.report, `${site.name}-${type === 'ai' ? '建站分析报告' : '周边可行性分析'}.md`, 'text/markdown;charset=utf-8');
    await loadSites();
    showDetail(site.id, { fly: false });
  } catch (e) {
    $('report-body').innerHTML = `<div class="empty-tip"><i class="fas fa-exclamation-circle"></i><p>${esc(e.message)}</p></div>`;
  }
}

function openReportModal(title) {
  $('report-title').innerHTML = '<i class="fas fa-file-alt"></i> ' + title;
  $('report-body').innerHTML = '<div class="report-loading"><i class="fas fa-spinner fa-spin"></i> 正在生成报告，请稍候（约 10-60 秒）…</div>';
  openModal('report-modal');
}

function showReport(siteId, type) {
  const site = state.sites.find(s => s.id === siteId);
  if (!site) return;
  const content = type === 'ai' ? site.aiReport : site.surroundingReport;
  openReportModal(type === 'ai' ? '建站分析报告' : '周边可行性分析');
  $('report-body').innerHTML = mdToHtml(content);
  $('report-download').onclick = () => downloadBlob(content, `${site.name}-${type === 'ai' ? '建站分析报告' : '周边可行性分析'}.md`, 'text/markdown;charset=utf-8');
}

/* ---------------- 分类管理 ---------------- */
async function renderCategoryList() {
  $('category-list').innerHTML = state.categories.map(c => `
    <div class="category-item">
      <span class="ci-name"><i class="fas fa-tag"></i>${esc(c)}</span>
      <button class="ci-del" data-cat="${esc(c)}" title="删除"><i class="fas fa-trash"></i></button>
    </div>`).join('');
  $('category-list').querySelectorAll('.ci-del').forEach(b => {
    b.onclick = () => confirmAction('删除分类', `确定删除分类「${b.dataset.cat}」吗？`, async () => {
      await api('/api/categories/' + encodeURIComponent(b.dataset.cat), { method: 'DELETE' });
      await loadCategories();
      renderCategoryList();
      toast('分类已删除', 'success');
    });
  });
}

/* ---------------- 用户管理 ---------------- */
async function renderUserList() {
  const users = await api('/api/users');
  $('users-tbody').innerHTML = users.map(u => `
    <tr>
      <td>${esc(u.username)} ${u.username === 'admin' ? '<span class="badge">超级管理员</span>' : ''}</td>
      <td>${u.role === 'admin' ? '管理员' : '普通用户'}</td>
      <td>${u.username === 'admin' ? '<span style="color:#94a3b8">不可删除</span>' : `<button class="btn btn-sm btn-outline" data-del-user="${esc(u.id)}"><i class="fas fa-trash"></i> 删除</button>`}</td>
    </tr>`).join('');
  $('users-tbody').querySelectorAll('[data-del-user]').forEach(b => {
    b.onclick = () => confirmAction('删除用户', '确定删除该用户吗？', async () => {
      await api('/api/users/' + b.dataset.delUser, { method: 'DELETE' });
      renderUserList();
      toast('用户已删除', 'success');
    });
  });
}

/* ---------------- 自定义字段管理 ---------------- */
const FIELD_TYPE_LABELS = { text: '文本框', textarea: '多行文本', number: '数字', radio: '单选', select: '下拉选择', checkbox: '多选' };
const ROLE_LABELS = { admin: '管理员', user: '普通用户', guest: '游客' };
let adminFields = [];   // 管理视角全量字段
let editingFieldId = null;

async function openFieldsModal() {
  adminFields = await api('/api/fields/admin');
  renderFieldList();
  hideFieldEditor();
  openModal('fields-modal');
}

function renderFieldList() {
  const box = $('field-list');
  $('field-empty').classList.toggle('hidden', adminFields.length > 0);
  box.innerHTML = adminFields.map((f, i) => `
    <div class="field-item">
      <span class="fi-label">${esc(f.label)}${f.required ? '<span class="fi-required"> *</span>' : ''}${f.internal ? ' <span class="badge">内置</span>' : ''}</span>
      <span class="fi-type">${FIELD_TYPE_LABELS[f.type] || f.type}</span>
      <span class="fi-vis">${f.visibleTo.map(r => ROLE_LABELS[r] || r).join('、')}</span>
      <span class="fi-ops">
        <button class="mo-btn" data-fm="up" data-idx="${i}" title="上移"><i class="fas fa-chevron-up"></i></button>
        <button class="mo-btn" data-fm="down" data-idx="${i}" title="下移"><i class="fas fa-chevron-down"></i></button>
        <button class="mo-btn" data-fm="edit" data-idx="${i}" title="编辑"><i class="fas fa-edit"></i></button>
        <button class="mo-btn mo-del" data-fm="del" data-idx="${i}" title="删除"><i class="fas fa-trash"></i></button>
      </span>
    </div>`).join('');
  box.querySelectorAll('[data-fm]').forEach(btn => {
    btn.onclick = () => {
      const idx = Number(btn.dataset.idx);
      const act = btn.dataset.fm;
      if (act === 'up') moveField(idx, -1);
      else if (act === 'down') moveField(idx, 1);
      else if (act === 'edit') openFieldEditor(adminFields[idx].id);
      else if (act === 'del') deleteField(adminFields[idx].id);
    };
  });
}

function hideFieldEditor() {
  $('field-editor').classList.add('hidden');
  editingFieldId = null;
}

function openFieldEditor(id) {
  editingFieldId = id || null;
  const f = id ? adminFields.find(x => x.id === id) : null;
  $('field-editor-title').textContent = f ? `编辑字段：${f.label}` : '添加字段';
  $('fe-label').value = f ? f.label : '';
  $('fe-type').value = f ? f.type : 'text';
  $('fe-options').value = f && f.options ? f.options.join('\n') : '';
  $('fe-placeholder').value = f && f.placeholder ? f.placeholder : '';
  $('fe-required').checked = !!(f && f.required);
  document.querySelectorAll('.fe-vis').forEach(cb => { cb.checked = !f || f.visibleTo.includes(cb.value); });
  syncFieldTypeUI();
  $('field-editor').classList.remove('hidden');
}

function syncFieldTypeUI() {
  const t = $('fe-type').value;
  $('fe-options-wrap').style.display = ['radio', 'select', 'checkbox'].includes(t) ? '' : 'none';
}

async function saveField() {
  const label = $('fe-label').value.trim();
  if (!label) return toast('请填写字段名称', 'error');
  const type = $('fe-type').value;
  const options = $('fe-options').value.split('\n').map(s => s.trim()).filter(Boolean);
  const visibleTo = [...document.querySelectorAll('.fe-vis:checked')].map(cb => cb.value);
  if (!visibleTo.length) return toast('至少选择一个可见角色', 'error');
  const body = { label, type, options, placeholder: $('fe-placeholder').value.trim(), required: $('fe-required').checked, visibleTo };
  try {
    if (editingFieldId) await api('/api/fields/' + editingFieldId, { method: 'PUT', body });
    else await api('/api/fields', { method: 'POST', body });
    toast('字段已保存', 'success');
    await refreshFieldsAndUI();
    hideFieldEditor();
  } catch (e) { toast(e.message, 'error'); }
}

async function deleteField(id) {
  confirmAction('删除字段', '删除后该字段在场地数据中的值也会同步清除，确定删除？', async () => {
    try {
      await api('/api/fields/' + id, { method: 'DELETE' });
      toast('字段已删除', 'success');
      await refreshFieldsAndUI();
    } catch (e) { toast(e.message, 'error'); }
  });
}

async function moveField(idx, dir) {
  const j = idx + dir;
  if (j < 0 || j >= adminFields.length) return;
  const arr = [...adminFields];
  [arr[idx], arr[j]] = [arr[j], arr[idx]];
  try {
    await api('/api/fields/reorder', { method: 'POST', body: { ids: arr.map(f => f.id) } });
    await refreshFieldsAndUI();
  } catch (e) { toast(e.message, 'error'); }
}

/** 字段变化后：刷新管理列表 + 当前角色字段 + 打开中的表单 */
async function refreshFieldsAndUI() {
  adminFields = await api('/api/fields/admin');
  renderFieldList();
  await loadFields();
  const formOpen = !$('site-form-modal').classList.contains('hidden');
  if (formOpen) {
    const site = state.editId ? state.sites.find(s => s.id === state.editId) : null;
    renderInternalFormFields(site);
    renderCustomFormFields(site);
  }
}

/* ---------------- 导入导出 ---------------- */
async function exportData(kind) {
  try {
    const mapKind = { json: ['json', 'sites-export.json', 'application/json'],
      csv: ['csv', 'sites-export.csv', 'text/csv;charset=utf-8'],
      'zip-json': ['json', 'sites-full-export.zip', 'application/zip'],
      'zip-csv': ['csv', 'sites-full-export.zip', 'application/zip'] };
    const [fmt, filename, mime] = mapKind[kind];
    const endpoint = kind.startsWith('zip') ? '/api/sites/export-full' : '/api/sites/export';
    const resp = await fetch(`${endpoint}?format=${fmt}`, { headers: { 'Authorization': 'Bearer ' + state.token } });
    if (!resp.ok) { const d = await resp.json().catch(() => ({})); throw new Error(d.error || '导出失败'); }
    downloadBlob(await resp.blob(), filename, mime);
    toast('导出成功', 'success');
  } catch (e) { toast(e.message, 'error'); }
}

function openImport(format) {
  $('import-format-label').textContent = '格式：' + format.toUpperCase();
  $('import-file').dataset.format = format;
  $('import-file-name').textContent = '选择文件（.' + format + '）';
  $('import-file').accept = '.' + format;
  $('import-file').value = '';
  $('import-result').style.display = 'none';
  openModal('import-modal');
}

async function submitImport() {
  const file = $('import-file').files[0];
  if (!file) return toast('请选择要导入的文件', 'error');
  const mode = document.querySelector('input[name="import-mode"]:checked').value;
  const dedupe = $('import-dedupe').checked;
  const fd = new FormData();
  fd.append('file', file);
  fd.append('mode', mode);
  fd.append('dedupe', dedupe ? '1' : '0');
  const box = $('import-result');
  try {
    const data = await api('/api/sites/import', { method: 'POST', body: fd });
    box.className = 'import-result';
    box.style.display = 'block';
    let msg = `✅ 导入完成：新增 ${data.added} 条，更新 ${data.updated} 条`;
    if (data.skipped) msg += `，去重跳过 ${data.skipped} 条`;
    if (data.errors && data.errors.length) msg += `<br>⚠️ 无效 ${data.errors.length} 条：<br>` + data.errors.slice(0, 8).map(esc).join('<br>');
    box.innerHTML = msg;
    await loadSites();
    if (data.errors && data.errors.length) box.classList.add('error');
  } catch (e) {
    box.className = 'import-result error';
    box.style.display = 'block';
    box.innerHTML = '❌ ' + esc(e.message);
  }
}

/* ---------------- 模态框通用 ---------------- */
function openModal(id) { $(id).classList.remove('hidden'); }
function closeModal(id) { $(id).classList.add('hidden'); }

function confirmAction(title, text, onOk) {
  $('confirm-title').textContent = title;
  $('confirm-text').textContent = text;
  openModal('confirm-modal');
  $('confirm-ok').onclick = async () => {
    closeModal('confirm-modal');
    try { await onOk(); } catch (e) { toast(e.message, 'error'); }
  };
}

function openLightbox(el) {
  const content = el.tagName === 'VIDEO'
    ? `<video src="${esc(el.src)}" controls autoplay></video>`
    : `<img src="${esc(el.src)}" alt="">`;
  $('lightbox-content').innerHTML = content;
  $('lightbox').classList.remove('hidden');
}

function closeDropdowns() {
  $$('.dropdown-menu').forEach(m => m.classList.remove('open'));
}

/* ---------------- 移动端抽屉 ---------------- */
function isMobile() { return window.innerWidth < 769; }

/** 同步 #main 状态类，驱动地图按钮位置联动（抽屉收起/展开/全屏） */
function syncDrawerUI() {
  const main = $('main');
  main.classList.toggle('drawer-collapsed', $('panel').classList.contains('collapsed'));
  main.classList.toggle('drawer-full', $('panel').classList.contains('full'));
}

/** 设置抽屉三态：collapsed(收起) / half(半屏) / full(全屏) */
function setDrawer(mode) {
  if (!isMobile()) return;
  const panel = $('panel');
  panel.classList.toggle('collapsed', mode === 'collapsed');
  panel.classList.toggle('full', mode === 'full');
  syncDrawerUI();
}

/** 点击把手：三态循环（收起 → 半屏 → 全屏 → 半屏） */
function cycleDrawer() {
  if (!isMobile()) return;
  const panel = $('panel');
  if (panel.classList.contains('collapsed')) setDrawer('half');
  else if (panel.classList.contains('full')) setDrawer('half');
  else setDrawer('full');
}

/* ---------------- 事件绑定 ---------------- */
function bindEvents() {
  // 下拉菜单
  $('user-btn').onclick = e => { e.stopPropagation(); $('user-menu').classList.toggle('open'); };
  $('import-export-btn').onclick = e => { e.stopPropagation(); $('import-export-menu').classList.toggle('open'); };
  document.addEventListener('click', closeDropdowns);

  // 用户菜单
  $('menu-login').onclick = e => { e.preventDefault(); openModal('login-modal'); };
  $('menu-logout').onclick = e => { e.preventDefault(); doLogout(); };
  $('menu-change-pwd').onclick = e => { e.preventDefault(); openModal('pwd-modal'); };
  $('menu-users').onclick = e => { e.preventDefault(); openModal('users-modal'); renderUserList(); };
  $('menu-categories').onclick = e => { e.preventDefault(); openModal('categories-modal'); renderCategoryList(); };
  $('menu-fields').onclick = e => { e.preventDefault(); openFieldsModal(); };
  $('menu-ai-config').onclick = e => { e.preventDefault(); openAiConfigModal(); };

  // 字段管理
  $('field-add-btn').onclick = () => openFieldEditor(null);
  $('fe-type').onchange = syncFieldTypeUI;
  $('fe-save').onclick = saveField;
  $('fe-cancel').onclick = hideFieldEditor;

  // 登录
  $('login-submit').onclick = async () => {
    const u = $('login-username').value.trim(), p = $('login-password').value;
    $('login-error').textContent = '';
    if (!u || !p) return $('login-error').textContent = '请输入用户名和密码';
    try {
      await doLogin(u, p);
      closeModal('login-modal');
      $('login-password').value = '';
    } catch (e) { $('login-error').textContent = e.message; }
  };
  $('login-password').addEventListener('keydown', e => { if (e.key === 'Enter') $('login-submit').click(); });

  // 修改密码
  $('pwd-submit').onclick = async () => {
    const oldP = $('pwd-old').value, newP = $('pwd-new').value, cf = $('pwd-confirm').value;
    if (!oldP || !newP) return toast('请填写完整', 'error');
    if (newP !== cf) return toast('两次输入的新密码不一致', 'error');
    try {
      await api('/api/users/password', { method: 'PUT', body: { oldPassword: oldP, newPassword: newP } });
      toast('密码已修改', 'success');
      closeModal('pwd-modal');
      $('pwd-old').value = $('pwd-new').value = $('pwd-confirm').value = '';
    } catch (e) { toast(e.message, 'error'); }
  };

  // 用户管理
  $('new-user-add').onclick = async () => {
    const name = $('new-user-name').value.trim(), pwd = $('new-user-pwd').value, role = $('new-user-role').value;
    if (!name || !pwd) return toast('请填写用户名和密码', 'error');
    try {
      await api('/api/users', { method: 'POST', body: { username: name, password: pwd, role } });
      toast('用户已添加', 'success');
      $('new-user-name').value = $('new-user-pwd').value = '';
      renderUserList();
    } catch (e) { toast(e.message, 'error'); }
  };

  // 分类管理
  $('new-category-add').onclick = async () => {
    const name = $('new-category-name').value.trim();
    if (!name) return toast('请输入分类名称', 'error');
    try {
      await api('/api/categories', { method: 'POST', body: { name } });
      toast('分类已添加', 'success');
      $('new-category-name').value = '';
      await loadCategories();
      renderCategoryList();
    } catch (e) { toast(e.message, 'error'); }
  };

  // AI 配置
  $('ai-config-save').onclick = async () => {
    try {
      await api('/api/ai/config', { method: 'PUT', body: {
        apiKey: $('ai-apikey').value.trim(), apiUrl: $('ai-apiurl').value.trim(),
        model: $('ai-model').value.trim(), amapKey: $('ai-amapkey').value.trim()
      } });
      toast('AI 配置已保存', 'success');
      closeModal('ai-config-modal');
    } catch (e) { toast(e.message, 'error'); }
  };

  // 地图按钮
  $('pick-point-btn').onclick = () => { state.pickMode ? exitPickMode() : enterPickMode('top'); };
  $('traffic-btn').onclick = toggleTraffic;
  $('reset-view-btn').onclick = resetView;

  // 地图 popup「查看详情」按钮（事件委托：Leaflet 的 popupopen 是 map 事件，不会冒泡到 marker，
  // 且 popup DOM 由 Leaflet 动态创建，全局委托最稳妥）
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.popup-detail-btn');
    if (btn) showDetail(btn.dataset.siteId, { fly: false });
  });

  // 导航选择
  $('nav-list').querySelectorAll('.nav-item').forEach(item => {
    item.onclick = () => launchNavigation(item.dataset.nav);
  });

  // 搜索 / 筛选
  $('search-input').addEventListener('input', debounce(e => { state.search = e.target.value; applyFilter(); }, 250));
  $('category-filter').onchange = e => { state.category = e.target.value; applyFilter(); };

  // 添加场地
  $('add-site-btn').onclick = () => openSiteForm(null);

  // 表单
  $('site-form-submit').onclick = submitSiteForm;
  $('f-pick-location').onclick = () => enterPickMode('form');
  $('f-show-pois').onclick = fetchFormPois;

  // 导入导出
  $('import-export-menu').querySelectorAll('[data-export]').forEach(a => {
    a.onclick = e => { e.preventDefault(); exportData(a.dataset.export); };
  });
  $('import-json-link').onclick = e => { e.preventDefault(); openImport('json'); };
  $('import-csv-link').onclick = e => { e.preventDefault(); openImport('csv'); };
  $('download-template-link').onclick = e => {
    e.preventDefault();
    const fmt = confirm('选择模版格式：\n确定 = CSV，取消 = JSON');
    const format = fmt ? 'csv' : 'json';
    fetch('/api/sites/import-template?format=' + format, { headers: { 'Authorization': 'Bearer ' + state.token } })
      .then(r => r.blob())
      .then(b => downloadBlob(b, `sites-import-template.${format}`, format === 'csv' ? 'text/csv;charset=utf-8' : 'application/json'))
      .catch(err => toast(err.message, 'error'));
  };
  $('import-submit').onclick = submitImport;
  $('import-file').onchange = e => {
    const f = e.target.files[0];
    if (f) $('import-file-name').textContent = f.name;
  };

  // 报告下载
  $('report-download').onclick = null; // 由 runAnalyze/showReport 动态绑定

  // 模态框关闭
  $$('.modal-close, [data-close]').forEach(el => {
    el.onclick = () => closeModal(el.dataset.close || el.closest('.modal-overlay').id);
  });
  $$('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('mousedown', e => { if (e.target === overlay) overlay.classList.add('hidden'); });
  });

  // 灯箱
  document.querySelector('.lightbox-close').onclick = () => $('lightbox').classList.add('hidden');
  $('lightbox').addEventListener('click', e => { if (e.target === $('lightbox')) $('lightbox').classList.add('hidden'); });

  // ESC
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      if (state.pickMode) return exitPickMode();
      $$('.modal-overlay:not(.hidden)').forEach(m => m.classList.add('hidden'));
      $('lightbox').classList.add('hidden');
    }
  });

  // 移动端：汉堡菜单（点外部关闭、选完分类关闭）
  $('menu-btn').onclick = e => { e.stopPropagation(); $('nav-center').classList.toggle('open'); };
  document.addEventListener('click', (e) => {
    const nc = $('nav-center');
    if (nc.classList.contains('open') && !nc.contains(e.target) && e.target !== $('menu-btn')) {
      nc.classList.remove('open');
    }
  });
  $('category-filter').addEventListener('change', () => $('nav-center').classList.remove('open'));

  // 移动端：抽屉把手（点击三态 + 拖拽跟手）
  $('drawer-handle').onclick = cycleDrawer;
  let startY = 0, dragging = false;
  $('drawer-handle').addEventListener('touchstart', e => {
    if ($('main').classList.contains('detail-mode')) return;
    dragging = true;
    startY = e.touches[0].clientY;
    $('panel').style.transition = 'none';
  }, { passive: true });
  $('drawer-handle').addEventListener('touchmove', e => {
    if (!dragging) return;
    e.preventDefault();
    const dy = e.touches[0].clientY - startY;
    const panel = $('panel');
    const h = panel.offsetHeight;
    const maxDown = h - 44;                       // 收起位移
    const ty = Math.max(-h * 0.45, Math.min(maxDown, dy));
    panel.style.transform = `translateY(${ty}px)`;
  }, { passive: false });
  $('drawer-handle').addEventListener('touchend', e => {
    if (!dragging) return;
    dragging = false;
    const panel = $('panel');
    panel.style.transition = '';
    panel.style.transform = '';
    const dy = e.changedTouches[0].clientY - startY;
    if (dy > 80) setDrawer('collapsed');
    else if (dy < -80) setDrawer('full');
    else setDrawer('half');
  });

  // 返回列表（移动端：抽屉回到半屏）
  $('back-btn').onclick = () => {
    state.selectedId = null;
    poiLayer.clearLayers();
    switchView('list');
    renderList(state.sites);
    renderMarkers(state.sites);
    $('main').classList.remove('detail-mode');
    setDrawer('half');
  };
}

/* ---------------- AI 配置模态框 ---------------- */
async function openAiConfigModal() {
  try {
    const cfg = await api('/api/ai/config');
    $('ai-apikey').value = cfg.apiKey || '';
    $('ai-apiurl').value = cfg.apiUrl || '';
    $('ai-model').value = cfg.model || '';
    $('ai-amapkey').value = cfg.amapKey || '';
    openModal('ai-config-modal');
  } catch (e) { toast(e.message, 'error'); }
}

/* ---------------- 路由：独立详情页 ?id=xxx ---------------- */
function handleRoute() {
  const params = new URLSearchParams(location.search);
  const id = params.get('id');
  if (!id) return;
  const site = state.sites.find(s => s.id === id);
  if (site) {
    showDetail(id, { fly: false });
    $('panel-title').textContent = '场地详情';
  }
}

/* ---------------- 初始化 ---------------- */
async function init() {
  initMap();
  bindEvents();
  updateAuthUI();
  try {
    await Promise.all([loadCategories(), loadSites(), loadFields()]);
  } catch (e) {
    toast('数据加载失败：' + e.message, 'error');
  }
  handleRoute();
}

document.addEventListener('DOMContentLoaded', init);
